package com.mindgate.service;

public interface EmployeeService {

	public boolean addEmployee();

	public void getEmployee();

}