package com.mindgate.service;

public class EmployeeApplication1 {
	public boolean addEmployee() {
		return false;
	}
	public boolean getEmployee() {
		return false;
	}
}
