package com.mindgate.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mindgate.config.ApplicationConfiguration;
import com.mindgate.pojo.Employee;

public class EmployeeMain {
	public static void main(String[] args) {
		System.out.println("Main Start");
		
		ApplicationContext applicationContext = new AnnotationConfigApplicationContext(ApplicationConfiguration.class);
		System.out.println("Application context");
		Employee employee = applicationContext.getBean("employee", Employee.class);
		
		System.out.println(employee);
		System.out.println("Main end");
	}
}
