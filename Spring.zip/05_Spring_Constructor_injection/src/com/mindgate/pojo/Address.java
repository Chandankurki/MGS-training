package com.mindgate.pojo;

public class Address {
	private String buildingName;
	private String street;
	private String city;
	private int pin;

	public Address() {
		System.out.println("Default constrcutor of Address");
	}

	public Address(String buildingName, String street, String city, int pin) {
		super();
		this.buildingName = buildingName;
		this.street = street;
		this.city = city;
		this.pin = pin;
		System.out.println("Overloaded constrcutor of Address");
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
		System.out.println("Setting buildingName");
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
		System.out.println("Setting street");
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
		System.out.println("Setting city");
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
		System.out.println("Setting pin");
	}

	@Override
	public String toString() {
		return "Address [buildingName=" + buildingName + ", street=" + street + ", city=" + city + ", pin=" + pin + "]";
	}
}
