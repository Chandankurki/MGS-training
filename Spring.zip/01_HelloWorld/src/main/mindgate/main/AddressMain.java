package main.mindgate.main;

import main.mindgate.pojo.Address;

public class AddressMain {
	public static void main(String[] args) {
		System.out.println("using Setter");
		Address address = new Address();
		address.setBuildingName("kochar Globe");
		address.setCity("chennai");
		address.setPin(600032);
		address.setStreet("sidco Industrial road");
		
		System.out.println(address);
		System.out.println();
		
		
		System.out.println("Using Param constr");
		
		Address address2= new Address("kochar Globe", "chennai","Sidco industrial area", 600032);
		System.out.println(address2);
	}
}
