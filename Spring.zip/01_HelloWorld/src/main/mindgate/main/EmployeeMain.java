package main.mindgate.main;

import main.mindgate.pojo.Address;
import main.mindgate.pojo.Employee;

public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			Address homeAddress = new Address();
			homeAddress.setBuildingName("Woodland Park");
			homeAddress.setCity("MG Road");
			homeAddress.setPin(560032);
			homeAddress.setStreet("bengaluru");
			
			Employee employee= new Employee();
			System.out.println(employee);
			employee.setEmployeeId(101);
			employee.setName("chandan k s");
			employee.setSalary(35000);
			employee.setHomeAdress(homeAddress);
			System.out.println(employee);
			
	}

}
