package main.mindgate.pojo;

public class Employee {
	private int employeeId;
	private String name;
	private float salary;
	private Address homeAdress;
	public Employee() {
		
		// TODO Auto-generated constructor stub
	}
	public Employee(int employeeId, String name, float salary, Address homeAdress) {
		super();
		this.employeeId = employeeId;
		this.name = name;
		this.salary = salary;
		this.homeAdress = homeAdress;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public Address getHomeAdress() {
		return homeAdress;
	}
	public void setHomeAdress(Address homeAdress) {
		this.homeAdress = homeAdress;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", name=" + name + ", salary=" + salary + ", homeAdress="
				+ homeAdress + "]";
	}
	
	
}
