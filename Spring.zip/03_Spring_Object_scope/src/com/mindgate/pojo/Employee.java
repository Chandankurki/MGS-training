package com.mindgate.pojo;

public class Employee {
	private String name;
	private int EMployeeId;
	private float salary;
	private String homeAddress;
	public Employee() {
System.out.println("Default constructor");	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getEMployeeId() {
		return EMployeeId;
	}
	public void setEMployeeId(int eMployeeId) {
		EMployeeId = eMployeeId;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public String getHomeAddress() {
		return homeAddress;
	}
	public void setHomeAddress(String homeAddress) {
		this.homeAddress = homeAddress;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", EMployeeId=" + EMployeeId + ", salary=" + salary + ", homeAddress="
				+ homeAddress + "]";
	}
	public Employee(String name, int eMployeeId, float salary, String homeAddress) {
		super();
		this.name = name;
		EMployeeId = eMployeeId;
		this.salary = salary;
		this.homeAddress = homeAddress;
	}


}
