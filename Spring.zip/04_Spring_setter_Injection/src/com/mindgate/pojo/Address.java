package com.mindgate.pojo;

public class Address {
	private String buildingName;
	private String street;
	private int pin;public Address() {
		// TODO Auto-generated constructor stub
		System.out.println("default constructor address");
	}
	public String getBuildingName() {
		return buildingName;
	}
	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
		System.out.println("setting building name");

	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
		System.out.println("setting street");

	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
		System.out.println("setting pin");

	}
	public Address(String buildingName, String street, int pin) {
		super();
		this.buildingName = buildingName;
		this.street = street;
		this.pin = pin;
	}
	@Override
	public String toString() {
		return "Address [buildingName=" + buildingName + ", street=" + street + ", pin=" + pin + "]";
	}
}
