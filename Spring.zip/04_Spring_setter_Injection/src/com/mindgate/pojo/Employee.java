package com.mindgate.pojo;

public class Employee {
	private String name;
	private int employeeId;
	private float salary;
	private Address homeAddress;
	public Employee() {
		// TODO Auto-generated constructor stub
		System.out.println("Default constructor");
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
		System.out.println("Setting Name");
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
		System.out.println("Setting employeeId");

	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
		System.out.println("Setting salary");

	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", employeeId=" + employeeId + ", salary=" + salary + ", homeAddress="
				+ homeAddress + "]";
	}
	public Address getHomeAddress() {
		return homeAddress;
	}
	public void setHomeAddress(Address homeAddress) {
		this.homeAddress = homeAddress;
		System.out.println("Setting homeAddress");

	}
	public Employee(String name, int employeeId, float salary, Address homeAddress) {
		super();
		this.name = name;
		this.employeeId = employeeId;
		this.salary = salary;
		this.homeAddress = homeAddress;
	}
}
