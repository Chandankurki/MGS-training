package com.mindgate.main.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.main.pojo.Employee;

@Repository
public class LoginRepository implements LoginRepositoryInterface {
	private static final String GET_Login_Details = "select * from login_details where loginId=? and password=?";
	@Autowired
	public JdbcTemplate jdbcTemplate;

	@Override
	public Employee login(Employee login) {
		Object[] args = { login.getLogin_id(), login.getPassword() };
		LoginRowMapper rowMapper = new LoginRowMapper();
		Employee employee = jdbcTemplate.queryForObject(GET_Login_Details, rowMapper, args);

		return employee;
	}
}
