package com.mindgate.main;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mindgate.main.pojo.Employee;
import com.mindgate.main.services.LoginServiceInterface;

@SpringBootApplication
public class Application {
	@Autowired
private static LoginServiceInterface loginServiceInterface;
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		ConfigurableApplicationContext applicationContext= SpringApplication.run(Application.class);
		
		loginServiceInterface = applicationContext.getBean("loginservice", LoginServiceInterface.class);
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter EmployeeId to login ");
		String loginId= sc.next();
		System.out.println("Enter password");
		String password = sc.next();
		
		Employee emp= new Employee(loginId, password, " ");
		emp = loginServiceInterface.Login(emp);
		if (emp) {
			System.out.println("Employee deleted successfully");
		} else {
			System.out.println("Failed to delete ");
		}
		System.out.println(emp);
		System.out.println("login successful");
		
	
		
	}

}
