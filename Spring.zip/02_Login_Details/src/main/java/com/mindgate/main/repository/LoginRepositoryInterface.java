package com.mindgate.main.repository;

import com.mindgate.main.pojo.Employee;

public interface LoginRepositoryInterface {
	Employee login(Employee login);
	
}
