package com.mindgate.main.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.pojo.Employee;
import com.mindgate.main.repository.LoginRepositoryInterface;

@Service("loginservice")
public class LoginService implements LoginServiceInterface {
@Autowired
	private static LoginRepositoryInterface loginRepositoryInterface;

	@Override
	public Employee Login(Employee loginId) {

		return loginRepositoryInterface.login(loginId);
	}

}
