package com.mindgate.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.mindgate.main.pojo.Employee;

public class LoginRowMapper  implements RowMapper<Employee>{

	@Override
	public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
		Employee employee = new Employee();
		
		String logId = rs.getString("login_id");
		String password = rs.getString("password");
		String role = rs.getString("role");
		
		employee.setLogin_id(logId);
		employee.setPassword(password);
		employee.setRole(role);
		
		return employee;
	}

}
