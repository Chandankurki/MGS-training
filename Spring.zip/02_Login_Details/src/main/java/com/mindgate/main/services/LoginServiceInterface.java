package com.mindgate.main.services;

import com.mindgate.main.pojo.Employee;

public interface LoginServiceInterface {
	Employee Login(Employee loginId);
}
