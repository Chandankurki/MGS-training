package com.mindgate.pojo;

public class Address {
	private String buildingname;
	private String street;
	private String city;
	private int pin;

	public Address() {
		// TODO Auto-generated constructor stub
	}

	public Address(String buildingname, String street, String city, int pin) {
		this.buildingname = buildingname;
		this.street = street;
		this.city = city;
		this.pin = pin;
	}

	@Override
	public String toString() {
		return "Address [buildingname=" + buildingname + ", street=" + street + ", city=" + city + ", pin=" + pin + "]";
	}

	public String getBuildingname() {
		return buildingname;
	}

	public void setBuildingname(String buildingname) {
		this.buildingname = buildingname;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}
}
