package com.mindgate.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("do get called");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("do post called");
		String userid = request.getParameter("loginId");
		String password = request.getParameter("userpassword");

		if (userid.equals("chandan") && password.equals("chandan@123")) {
//			out.println("Login success");
			response.sendRedirect("Success.html");
		} else {
			out.println("Login failed");
			response.sendRedirect("Failure.html");
		}
	}

}
