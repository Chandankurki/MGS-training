package com.mindgate.pojo;

public class A {
	public A() {
		System.out.println("Hi");
	
}public A(int x) {
	System.out.println("Hi" + x);
}
	
}