package com.mindgate.pojo;

public class B extends A{
	public B() {
		System.out.println("Hello");
	}
	public B(int x) {
//		super(x);
		System.out.println("Hello" + x);
	}
}
