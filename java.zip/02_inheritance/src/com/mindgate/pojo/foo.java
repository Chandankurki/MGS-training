package com.mindgate.pojo;

public class foo {
	public void display() {
		System.out.println("display()of Foo class");
		
		
	}
}
