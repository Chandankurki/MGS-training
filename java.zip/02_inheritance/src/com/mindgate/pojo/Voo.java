package com.mindgate.pojo;

public class Voo extends foo {
	public void display() {
		super.display();
		System.out.println("dispaly() of Voo class");
		
	}
	
	 public void show() {
		 System.out.println("show() of Voo class");
//		Reusability
//		 foo foo = new foo();
//		 foo.display();
		 
		 
	 }
}
