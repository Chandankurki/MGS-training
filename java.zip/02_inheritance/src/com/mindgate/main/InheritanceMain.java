package com.mindgate.main;
import com.mindgate.pojo.Voo;

public class InheritanceMain {
	public static void main(String[] args) {
		Voo voo = new Voo();
		//voo.show();
		voo.display();
		
	}
}
