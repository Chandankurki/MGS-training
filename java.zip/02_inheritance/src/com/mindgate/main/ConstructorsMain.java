package com.mindgate.main;

import com.mindgate.pojo.B;

public class ConstructorsMain {
	public static void main(String[] args) {
		System.out.println("In Main");
		B b = new B(10);
//		B b;
		
		System.out.println("Main end");
	}
}
