package com.Mindgate.main;

import java.util.Scanner;

import com.Mindgate.pojo.ClassApplication;
import com.Mindgate.pojo.ClassUser;

public class ClassAppliactionMain {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter LoginId");
		String loginId = scanner.next();
		System.out.println("Enter Password");
		String password = scanner.next();

		ClassUser user = new ClassUser(loginId, password);

		ClassApplication application = new ClassApplication();

		boolean result = application.validateUser(user);
		if (result == true) {
			System.out.println("login succcess");
		} else {
			System.out.println("login failed");
		}
	}
}
