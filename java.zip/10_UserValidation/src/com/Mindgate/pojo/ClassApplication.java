package com.Mindgate.pojo;

public class ClassApplication {

	public boolean validateUser(ClassUser user) {
		if (user.getLoginId().equals("admin") && user.getPassword().equals("mindgate@123")) {
			return true;
		}
		return false;
	}

}


