package com.Mindgate.main;

import com.Mindgate.pojo.Calculation;

public class CalculationMain {
	public static void main(String[] args) {
		Calculation calculation = new Calculation();
		try {

			calculation.accept();
		} catch (NumberFormatException e) {
			System.out.println("Invalid Number");
		}
		calculation.division();
		calculation.display();
	}
}
