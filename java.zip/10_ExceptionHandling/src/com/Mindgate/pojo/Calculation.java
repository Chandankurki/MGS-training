package com.Mindgate.pojo;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Calculation {
	double number1, number2, result;

//	accept 2 number
	public void accept() throws NumberFormatException {
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter number1");
			number1 = sc.nextDouble();
			System.out.println("Enter number2");
			number2 = sc.nextDouble();
			if (number1 > 50) {
				throw new NumberFormatException();
			}
		} catch (InputMismatchException e) {
			System.out.println(e.getMessage());

		} finally {
			System.out.println("Finally block executed");
		}
	}
//	do division
	public void division() {
		result = number1 / number2;
	}
//	display the result
	public void display() {
		System.out.println("Result :" + result);
	}

}
