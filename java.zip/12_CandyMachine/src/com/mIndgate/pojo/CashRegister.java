package com.mIndgate.pojo;

public class CashRegister {
	private int cashOnHand;

	public CashRegister() {
		cashOnHand = 500;
	}

	public CashRegister(int cashOnHand) {
		this.cashOnHand = cashOnHand;
	}

	public int getCurrentBalance() {
		return cashOnHand;
	}

	public void acceptAmount(int amount) {
		cashOnHand = cashOnHand + amount;
	}
	public void updateCashOnHand(int amount) {
		cashOnHand= cashOnHand-amount;
	}
}
