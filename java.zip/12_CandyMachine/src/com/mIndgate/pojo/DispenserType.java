package com.mIndgate.pojo;

public class DispenserType {
	private int numberOfItems;
	private int cost;

	public DispenserType() {
		numberOfItems = 50;
		cost = 50;

	}

	public DispenserType(int numberOfItems, int cost) {
		this.numberOfItems = numberOfItems;
		this.cost = cost;
	}

	public int getNumberOfItems() {
		return numberOfItems;
	}

	public int getCost() {
		return cost;
	}
	public void makeSale() {
		numberOfItems=numberOfItems-1;
	}

}
