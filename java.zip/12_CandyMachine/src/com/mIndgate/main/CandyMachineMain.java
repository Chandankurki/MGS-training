package com.mIndgate.main;

import java.util.Scanner;

import com.mIndgate.pojo.CashRegister;
import com.mIndgate.pojo.DispenserType;

public class CandyMachineMain {
	public static void main(String[] args) {
		int selectedchoice;
		int depositedAmount;
		String continueChoice;

		Scanner scanner = new Scanner(System.in);
		DispenserType candies = new DispenserType(10, 20);
		DispenserType chips = new DispenserType(10, 10);
		DispenserType gum = new DispenserType(10, 5);
		DispenserType cookies = new DispenserType(10, 30);

		System.out.println("Welcome Candy Machine");
		System.out.println("Menu");
		System.out.println("1.Candies");
		System.out.println("2.Chips");
		System.out.println("3.Gum");
		System.out.println("4.Cookies");
		System.out.println("Please make a choice");

		selectedchoice = scanner.nextInt();

		CashRegister cashRegister = new CashRegister();
		do {
			switch (selectedchoice) {
			case 1:
				System.out.println("You have selected Candies");
				if (candies.getNumberOfItems() > 0) {
					System.out.println("Available Quantity = " + candies.getNumberOfItems());
					System.out.println("Cost of 1 Candy = " + candies.getCost() + " Rs");

					System.out.println("Please deposit the money");
					depositedAmount = scanner.nextInt();
					cashRegister.acceptAmount(depositedAmount);
					if (cashRegister.getCurrentBalance() >= candies.getCost()) {
						candies.makeSale();
						cashRegister.updateCashOnHand(candies.getCost());
						System.out.println("Please collect the Candy");
						System.out.println("Your current balance :: " + cashRegister.getCurrentBalance());
						System.out.println("Thanks for shopping!!");
					}

				} else {
					System.out.println("Sorry No Candies are available");
				}
				break;
			case 2:
				System.out.println("You have selected Chips");
				if (chips.getNumberOfItems() > 0) {
					System.out.println("Available Quantity = " + chips.getNumberOfItems());
					System.out.println("Cost of 1 Chips = " + chips.getCost() + " Rs");

					System.out.println("Please deposit the money");
					depositedAmount = scanner.nextInt();
					// CashRegister cashRegister = new CashRegister(depositedAmount);
					cashRegister.acceptAmount(depositedAmount);
					if (cashRegister.getCurrentBalance() >= chips.getCost()) {
						candies.makeSale();
						cashRegister.updateCashOnHand(chips.getCost());
						System.out.println("Please collect the Chips");
						System.out.println("Thanks for shopping!!");
					}
				} else {
					System.out.println("Sorry No Chips are available");
				}
				break;
			case 3:
				System.out.println("You have selected Gum");
				if (gum.getNumberOfItems() > 0) {
					System.out.println("Available Quantity = " + gum.getNumberOfItems());
					System.out.println("Cost of 1 Gum = " + gum.getCost() + " Rs");

					System.out.println("Please deposit the money");
					depositedAmount = scanner.nextInt();
					// CashRegister cashRegister = new CashRegister(depositedAmount);
					cashRegister.acceptAmount(depositedAmount);
					if (cashRegister.getCurrentBalance() >= gum.getCost()) {
						candies.makeSale();
						cashRegister.updateCashOnHand(gum.getCost());
						System.out.println("Please collect the Gum");
						System.out.println("Thanks for shopping!!");
					}
				} else {
					System.out.println("Sorry No Gum are available");
				}
				break;
			case 4:
				System.out.println("You have selected Cookies");
				if (cookies.getNumberOfItems() > 0) {
					System.out.println("Available Quantity = " + cookies.getNumberOfItems());
					System.out.println("Cost of 1 Cookies = " + cookies.getCost() + " Rs");

					System.out.println("Please deposit the money");
					depositedAmount = scanner.nextInt();
					// CashRegister cashRegister = new CashRegister(depositedAmount);
					cashRegister.acceptAmount(depositedAmount);
					if (cashRegister.getCurrentBalance() >= cookies.getCost()) {
						candies.makeSale();
						cashRegister.updateCashOnHand(cookies.getCost());
						System.out.println("Please collect the Cookies");
						System.out.println("Thanks for shopping!!");
					}
				} else {
					System.out.println("Sorry No Cookies are available");
				}
				break;

			default:
				System.out.println("Invalid Entry");
				break;

			}
			System.out.println("Do you want to buy more products..?");
			continueChoice = scanner.next();
		} while (continueChoice.equals("yes"));
	}
}