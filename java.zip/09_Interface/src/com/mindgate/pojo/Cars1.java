package com.mindgate.pojo;

public interface Cars1 {
	public void setCarModel(); 
}
