package com.mindgate.pojo;

public class Breeza implements Cars1 {
	@Override
	public void setCarModel() {
		
	}
}
