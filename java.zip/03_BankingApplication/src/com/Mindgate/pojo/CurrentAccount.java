package com.Mindgate.pojo;

public class CurrentAccount extends Accounts {
	private double overdraftBalance;
	private double initialOverdraftBalance;

	public CurrentAccount() {
		System.out.println("Default constructor of current");
	}

	public CurrentAccount(int accountNumber, String name, double balance, double overdraftBalance) {
		super(accountNumber, name, balance);
		this.overdraftBalance = overdraftBalance;
		initialOverdraftBalance = overdraftBalance;
		System.out.println("Overloaded constructor of current");
	}

	@Override
	public boolean withdraw(double amount) {
		if (amount > 0) {
			if (amount <= getBalance()) {
				setBalance(getBalance() - amount);
				return true;
			}
			if (amount < getBalance() + overdraftBalance && amount > getBalance()) {
				double deduct = amount - getBalance();
				setBalance(0);
				overdraftBalance = overdraftBalance - deduct;
				return true;
			}
		}
		return false;

	}

	@Override
	public boolean deposit(double amount) {
		if (amount > 0) {
			if (initialOverdraftBalance == overdraftBalance) {
				setBalance(getBalance() + amount);
				return true;
			}
			if (initialOverdraftBalance > overdraftBalance) {
				if (amount > (initialOverdraftBalance - overdraftBalance)) {
					amount = amount - (initialOverdraftBalance - overdraftBalance);
					setOverdraftBalance(initialOverdraftBalance);
					setBalance(getBalance() + amount);
					return true;
				} else {
					overdraftBalance = overdraftBalance + amount;
					return true;
				}
			}
		}
		return false;
	}

	public double getOverdraftBalance() {
		return overdraftBalance;
	}

	public void setOverdraftBalance(double overdraftBalance) {
		this.overdraftBalance = overdraftBalance;
	}

}
