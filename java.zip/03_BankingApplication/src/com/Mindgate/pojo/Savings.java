package com.Mindgate.pojo;

public class Savings extends Accounts{
	private boolean isSalary;
	public Savings() {
		System.out.println("Default Construactor of Savings");
	}
	public Savings(int accountNumber, String name, double balance, boolean isSalary) {
		super(accountNumber, name, balance);
		this.isSalary = isSalary;
		System.out.println("Overloaded Constructor of Savings");
		
	}
	@Override
	public boolean withdraw(double amount) {
		if (amount>0){
			if(isSalary == true && amount <=getBalance()) {
				System.out.println("in salary ");
				double updatedBalance = getBalance() - amount;
				setBalance(updatedBalance);
				return true;
			}
			if (isSalary == false && (getBalance()-amount) >=500) {
				System.out.println("in  savings");
				double updatedBalance = getBalance() -amount;
				setBalance(updatedBalance);
				return true;
			}
			
		}
		return false;
	}
	@Override
	public boolean deposit(double amount) {
		if (amount>0) {
			double updatedBalance = getBalance() +amount;
			setBalance(updatedBalance);
			return true;
		}
		return false;
	}
}
