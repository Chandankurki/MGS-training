package com.Mindgate.Main;

import com.Mindgate.pojo.Savings;

public class SavingsAccountMain {
	public static void main(String[] args) {
		Savings savings = new Savings(101, "Chandan", 1000, false);
		boolean result = savings.withdraw(1000);
		if (result) {
			System.out.println("Transaction success");
			System.out.println(savings.getBalance());
		} else {
			System.out.println("Transaction Failed");
			System.out.println(savings.getBalance());
		}
	}
}
