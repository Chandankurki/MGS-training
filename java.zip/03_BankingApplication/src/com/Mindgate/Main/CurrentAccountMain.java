package com.Mindgate.Main;

import com.Mindgate.pojo.CurrentAccount;

public class CurrentAccountMain {
	public static void main(String[] args) {
		CurrentAccount current = new CurrentAccount(101, "Chandan", 10000, 50000);
		boolean result;
		System.out.println("Withdraw  :  5000 ");
		result = current.withdraw(5000);
		System.out.println("Result : " + result);
		System.out.println("Balance : " + current.getBalance());
		System.out.println("Overdraft Balance :: " + current.getOverdraftBalance());

		System.out.println();

		System.out.println("Withdraw  :  10000 ");
		result = current.withdraw(10000);
		System.out.println("Result : " + result);
		System.out.println("Balance : " + current.getBalance());
		System.out.println("Overdraft Balance :: " + current.getOverdraftBalance());

		System.out.println();

		System.out.println("Deposit  :  3000 ");
		result = current.deposit(3000);
		System.out.println("Result : " + result);
		System.out.println("Balance : " + current.getBalance());
		System.out.println("Overdraft Balance :: " + current.getOverdraftBalance());

		System.out.println();

		System.out.println("Deposit  :  10000 ");
		result = current.deposit(10000);
		System.out.println("Result : " + result);
		System.out.println("Balance : " + current.getBalance());
		System.out.println("Overdraft Balance :: " + current.getOverdraftBalance());

	}
}
