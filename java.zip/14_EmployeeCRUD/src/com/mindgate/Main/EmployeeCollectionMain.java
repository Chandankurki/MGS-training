package com.mindgate.Main;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.mindgate.collection.EmployeeCollection;
import com.mindgate.pojo.Employee;

public class EmployeeCollectionMain {

	public static void main(String[] args) {
		EmployeeCollection employeeCollection = new EmployeeCollection();
		Employee employee = new Employee();
		employee.setEmployeeId(100);
		employee.setName("chandan");
		employee.setSalary(1000);

		employeeCollection.add(employee);
		Scanner scanner = new Scanner(System.in);

		Collection<Employee> c = new ArrayList<Employee>();
		int choice = 0;

		String continueChoice;
		do {
			System.out.println("Welcome to Employee Portal");
			System.out.println("Menu");
			System.out.println("1. Add Employee");
			System.out.println("2. Update Employee name");
			System.out.println("3. Update Employee salary ");
			System.out.println("4. Get the Employee details");
			System.out.println("5. Delete employee");	
			System.out.println("6. Get All Employee");
			System.out.println("Enter your choice");
			choice = scanner.nextInt();

			boolean condition = true;
			switch (choice) {
			case 1:
				System.out.print("Enter Employee Id");
				int employeeId = scanner.nextInt();
				System.out.print("Enter Employee Name");
				String name = scanner.next();
				System.out.print("Enter Employee Salary");
				int salary = scanner.nextInt();
				employee = new Employee(employeeId, name, salary);
				employeeCollection.addEmployee(employee);
				System.out.println(employee.toString());
				break;
				
			case 2:
				System.out.println("Enter employee id to be updated");
				System.out.print("Press 1 to update Name");
				String ch1 = scanner.next();
//				employeeCollection.updateName(employeeId, name);				
				break;
				
//			case 3:
//				System.out.println("Enter employee Name to be updated");
//				System.out.print("Press 1 to update Salary");
//				int ch2 = scanner.nextInt();
//				employeeCollection.updateSalary(employee, salary);
//				break;
				
			case 4:
				System.out.print("Enter employee id to find : ");
				employeeId = scanner.nextInt();
				System.out.println(employee.getEmployeeId());				
				break;
				
			case 5:
				System.out.print("Enter employee id to delete : ");
				 int rId = scanner.nextInt();				 
	             employeeCollection.delete(rId);				
				break;
				
			case 6:
				System.out.print("Press y to display all employee details");
				String Allemp = scanner.next();
				System.out.println(employeeCollection.display());
				break;
			default:
				System.out.println("Invalid Entry");

				break;
			}
			System.out.println("Do you want to continue");
			continueChoice = scanner.next();

		} while (continueChoice.equals("yes"));

	}
	
	
	
}
