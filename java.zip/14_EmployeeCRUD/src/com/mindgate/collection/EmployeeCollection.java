package com.mindgate.collection;

//import java.util.ArrayList;
import java.util.LinkedList;
//import java.util.List;
import java.util.Scanner;

import com.mindgate.pojo.Employee;

public class EmployeeCollection {

	LinkedList<Employee> list;

	public EmployeeCollection() {
		list = new LinkedList<>();
	}

	public boolean addEmployee(Employee employee) {
		if (!find(employee.getEmployeeId())) {
			list.add(employee);
		}
		return true;
	}

	public boolean find(int employeeId) {
		for (Employee l : list) {
			if (l.getEmployeeId() == employeeId) {
				return true;
			}
		}
		return false;
	}

	public boolean delete(int rId) {
		Employee recordDel = null;
		for (Employee l : list) {
			if (l.getEmployeeId() == rId) {
				recordDel = l;
			}
		}
		if (recordDel == null) {
			return false;
		} else {

			list.remove(recordDel);
			return true;
		}
	}

	public Record findRecord(int employeeId) {
		for (Employee l : list) {
			if (l.getEmployeeId() == employeeId) {
			}
		}

		return null;
	}

	public boolean update(int employeeId, Scanner input) {

		if (find(employeeId)) {
			Employee rec = addEmployee(employeeId);
			employeeId = input.nextInt();
			String name = input.nextLine();
			rec.setEmployeeId(employeeId);
			rec.setName(name);
			return true;
		} else {
			return false;
		}
	}

	private Employee addEmployee(int employeeId) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean display() {
		if (list.isEmpty()) {
			return false;
		}
		for (Employee employee : list) {
			System.out.println(employee.toString());
		}
		return true;
	}

	private int getemployeeId() {
		for (Employee l : list) {
			if (l.getEmployeeId() == getemployeeId()) {
			}
		}

		return 0;
	}

	public void add(Employee employee) {
		// TODO Auto-generated method stub
		
	}


}