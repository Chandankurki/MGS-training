package com.Mindgate.Pojo;

public class Dispenser {

	public Dispenser(int i, int j) {
		// TODO Auto-generated constructor stub
	}

	public int getCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getProductCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void makeSale() {
		// TODO Auto-generated method stub
		
	}

}
