package com.Mindgate.Pojo;

public class CashRegister {

	public void acceptAmount(int coinsInserted) {
		// TODO Auto-generated method stub
		
	}

}
