package com.Mindgate.main1;

public class Flight {
	
		private int flightNumber;
		private String destination;
		private float distance;
		private double fuel;
	
		
		public Flight(int flightNumber, String destination,float distance,double fuel ) {
			this.destination = destination;
			this.distance = distance;
			this.flightNumber = flightNumber;
			this.fuel = fuel;
			
		
			
		}

		public int getFlightNumber() {
			return flightNumber;
		}

		public void setFlightNumber(int flightNumber) {
			this.flightNumber = flightNumber;
		}

		public String getDestination() {
			return destination;
		}

		public void setDestination(String destination) {
			this.destination = destination;
		}

		public float getDistance() {
			return distance;
		}

		public void setDistance(float distance) {
			this.distance = distance;
			
		}
		public double getFuel() {
			return fuel;
		}

		public void setFuel(double fuel) {
			this.fuel = fuel;
		}

		@Override
		public String toString() {
			return "Flight [flightNumber=" + flightNumber + ", destination=" + destination + ", distance=" + distance
					+ ", fuel=" + fuel + "]";
		}

		public double calfuel (double fuel);
		{
			if ()
			return fuel;	}
		
	

