package com.Mindgate.main2;

import java.util.Scanner;

import com.Mindgate.main1.Flight;

public class FlightMain {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String continueChoice;
		System.out.println("Welcome to Mind Gate Airline");
		System.out.println("Enter Flight data");
		System.out.println("Enter Flight No");
		int flightNo = scan.nextInt();
		System.out.println("Enter Destination");
		String destination = scan.next();
		System.out.println("Enter Distance");
		float distance = scan.nextFloat();
		System.out.println("Enter Fuel Liters");
		double fuel = scan.nextDouble();

		Flight flight = new Flight(flightNo, destination, distance, fuel);
		
		do {
		System.out.println(" 1. Calculate Fuel");
		System.out.println(" 2. Feed Info");
		System.out.println(" 3. Show Info");
		int choice = scan.nextInt();
		
		switch (choice) {
		case 1:
			if (flight.getDistance() <= 1000) {
				System.out.println("The Flight have an Fuel 500 Liters");
			} else if (flight.getDistance() >= 1000 && flight.getDistance() <= 2000) {
				System.out.println("The Flight have an Fuel 1100 Liters");
			} else if (flight.getDistance() >= 2000) {
				System.out.println("The Flight have an Fuel 2200 Liters");
			} else
				System.out.println("The Flight did't an have Fuel");

		case 2:			
			System.out.println("Enter Flight Number ");
			int no = scan.nextInt();
			if (flight.getFlightNumber() == no) {
				System.out.println("The Flight Destination is : " + flight.getDestination());
				System.out.println("The Flight Distance is : "+flight.getDistance()+" Km");
				
				if (flight.getDistance() <= 1000) {
					System.out.println("Consume the 500 Liters Fuel of travel  to distance");
				} else if (flight.getDistance() >= 1000 && flight.getDistance() <= 2000) {
					System.out.println("Consume the 1100 Liters Fuel of travel  to distance");
				} else if (flight.getDistance() >= 2000) {
					System.out.println("Consume the 2200 Liters Fuel of travel  to distance");
				} else
					System.out.println("The Flight dont have Fuel");

			} else
				System.out.println("Flight Number not Right  ,Try Again");
		case 3:
			System.out.println("The Flight No is : "+flight.getFlightNumber());
			System.out.println("The Flight Destination is : " + flight.getDestination());
			System.out.println("The Flight Distance is : "+flight.getDistance()+" Km");
			System.out.println("The Flight have an tank of Fuel is : "+flight.getFuel());
			if (flight.getDistance() <= 1000) {
				System.out.println("Consume the 500 Liters Fuel of travel  to distance");
			} else if (flight.getDistance() >= 1000 && flight.getDistance() <= 2000) {
				System.out.println("Consume the 1100 Liters Fuel of travel  to distance");
			} else if (flight.getDistance() >= 2000) {
				System.out.println("Consume the 2200 Liters Fuel of travel  to distance");
			} else
				System.out.println("The Flight have low Fuel, below 500 liters");
		}
		System.out.println("Do you want to continue?");
		continueChoice = scan.next();
		}while(continueChoice.equals("yes") && continueChoice.equals("Yes") && continueChoice.equals("YES") && continueChoice.equals("Y") && continueChoice.equals("y"));
		scan.close();

	}
}
