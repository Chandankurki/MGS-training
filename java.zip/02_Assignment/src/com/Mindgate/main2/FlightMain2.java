package com.Mindgate.main2;

import java.util.Scanner;

import com.Mindgate.main1.Flight;

public class FlightMain2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String continueChoice ;
		System.out.println("Welcome to Mindgate Airlines");
		System.out.println("Please enter Flight date");
		System.out.println("Enter flight number : ");
		int flightNumber= sc.nextInt();
		System.out.println("Enter Destination");
		String destination =sc.next();
		System.out.println("Enter Distance");
		float distance = sc.nextFloat();
		System.out.println("Enter quantity of fuel ");
		double fuel = sc.nextDouble();
		
//		Flight flight1 = new Flight(flightNumber,destination,distance,fuel);
//		do {
//			System.out.println("1. Flight number");
//			System.out.println("2.Feed info");
//			System.out.println("3.Show info");
//			int choice = sc.nextInt();
//		
////			switch (choice) {
////			if 
////			}
//		}
		
	}

}
