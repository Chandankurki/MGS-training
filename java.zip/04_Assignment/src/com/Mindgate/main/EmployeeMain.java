package com.Mindgate.main;

import java.util.Scanner;

import com.Mindgate.pojo.EmployeeDetails;

public class EmployeeMain {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter employeeId");
		int employeeId = sc.nextInt();
		System.out.println("Enter name");
		String name = sc.next();
		System.out.println("enter salary");
		float basic = sc.nextFloat();
		System.out.println("Enter hra");
		float hra = sc.nextFloat();
		System.out.println("enter Ta");
		float ta = sc.nextFloat();
		System.out.println("enter tax");
		float tax = sc.nextFloat();

		EmployeeDetails emp = new EmployeeDetails();
		{
			emp.calculateSalary();
			System.out.println("EmployeeId : " + employeeId + " Salary  " + emp.calculateSalary());
		}

	}
}
