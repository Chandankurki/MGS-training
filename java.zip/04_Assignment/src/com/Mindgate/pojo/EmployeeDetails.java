package com.Mindgate.pojo;

public class EmployeeDetails {
	private int employeeId;
	private String name;
	private float basic;
	private float hra;
	private float ta;
	private float tax;

	public EmployeeDetails() {
		System.out.println();
	}

	public EmployeeDetails(int employeeId, String name, float basic, float hra, float ta, float tax) {
		super();
		this.employeeId = employeeId;
		this.name = name;
		this.basic = basic;
		this.hra = hra;
		this.ta = ta;
		this.tax = tax;
	}

	public double calculateSalary() {
		double calculateSalary = ((basic + hra + ta) - tax);
		System.out.println("EmployeeId : " + employeeId + " Salary  " + calculateSalary);
		return calculateSalary;
	}

}
