package com.Mindgate.pojo;

public class LargestNumber {
	public int findtheLargest(int[] numbers) {
		int max = 0;
		for (int i : numbers) {
			if (i > max) {
				max = i;
			}
		}
		return max;
	}
}
