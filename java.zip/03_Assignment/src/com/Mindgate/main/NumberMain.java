package com.Mindgate.main;

import java.util.Scanner;

import com.Mindgate.pojo.LargestNumber;

public class NumberMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		LargestNumber numbersApplication = new LargestNumber();
		int[] numbers = new int[5];

		for (int i = 0; i < 5; i++) {
			System.out.print("Enter Number : ");
			numbers[i] = scanner.nextInt();
		}

		int max = numbersApplication.findtheLargest(numbers);

		System.out.println("Largest :: " + max);
	}
	
}
