package co.mindgate.pojo;

public class Voo extends Foo {
	public void print() {
		System.out.println("Hello");
	}
}
