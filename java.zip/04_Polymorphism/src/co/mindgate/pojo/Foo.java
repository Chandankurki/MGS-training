package co.mindgate.pojo;

public class Foo {
	public void print() {
		System.out.println("Hi");
	}
}
