package co.mindgate.main;

import co.mindgate.pojo.Foo;
import co.mindgate.pojo.Voo;

public class Main {
	public static void main(String[] args) {
		Foo foo = new Voo();
		foo.print();
	}

}
