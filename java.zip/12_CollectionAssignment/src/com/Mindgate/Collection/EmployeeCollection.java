package com.Mindgate.Collection;

import java.util.ArrayList;
import java.util.List;

import com.Mindgate.pojo.Employee;

public class EmployeeCollection {
	private List<Employee> employeeList = new ArrayList<Employee>();
	public boolean addEmployee(Employee employee) {
		System.out.println("In addEmployee method");
		System.out.println(employee);
		boolean result = employeeList.add(employee);
		return result;
	}
	
}
