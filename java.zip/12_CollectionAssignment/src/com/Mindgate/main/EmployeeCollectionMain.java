package com.Mindgate.main;

import java.util.ArrayList;
import java.util.List;

import com.Mindgate.pojo.Employee;

public class EmployeeCollectionMain {
	public static void main(String[] args) {
		List<Employee> employee = new ArrayList<Employee>();
		System.out.println(" List Size ::" + employee.size());

		Employee employee1 = new Employee(101, "Chandan", 1000);
		Employee employee2 = new Employee(102, "Suman", 2000);
		Employee employee3 = new Employee(103, "Santhosh", 2500);
		Employee employee4 = new Employee(104, "Abhi", 1000);
		Employee employee5 = new Employee(105, "vivek", 4000);

		employee.add(employee1);
		employee.add(employee2);
		employee.add(employee3);
		employee.add(employee4);
		employee.add(employee5);
		System.out.println(" List Size ::" + employee.size());

		for (Employee e : employee)
			System.out.println(e);
		System.out.println("***********************************************");

		for (Employee e : employee)
			if (e.getSalary() > 2000) {
				System.out.println(e);

			}
		System.out.println("***********************************************");
		for (Employee e : employee)
			if (e.getName().startsWith("C")) {
				System.out.println(e);

			}

	}
}
