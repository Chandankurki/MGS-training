package com.Mindgate.main;

import com.Mindgate.Collection.EmployeeCollection;
import com.Mindgate.pojo.Employee;

public class EmployeeCollectionApp {
	public static void main(String[] args) {
		System.out.println("Main Start");
		
		EmployeeCollection employeeCollection = new EmployeeCollection();
		
		Employee employee = new Employee(101, "Chandan", 1000);
		boolean result =employeeCollection.addEmployee(employee);
		if(result == true) {
			System.out.println("Employee added in collection");
		}else {
			System.out.println("failed to add Employee in collection");
		}
		System.out.println("Main End");
	}
}
