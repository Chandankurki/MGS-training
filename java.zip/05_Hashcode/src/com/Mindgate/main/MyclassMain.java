package com.Mindgate.main;

import com.Mindgate.pojo.Myclass;

public class MyclassMain {
	public static void main(String[] args) {
		Myclass myclass =new Myclass();
		
		System.out.println("object1 :" +myclass.hashCode());
		Myclass myclass2 =new Myclass();
		System.out.println("object2 :" +myclass2.hashCode());
		Myclass myclass3 = new Myclass();
		System.out.println("object3 :" +myclass3.hashCode());
	}
}
