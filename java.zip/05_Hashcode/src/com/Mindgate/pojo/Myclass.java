package com.Mindgate.pojo;

public class Myclass {
	public void print() {
		System.out.println("Hello");
	}
}
