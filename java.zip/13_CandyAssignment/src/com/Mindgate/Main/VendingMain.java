package com.Mindgate.Main;

import java.util.Scanner;
import com.Mindgate.pojo.*;

public class VendingMain {

	public static void main(String[] args) {

		CashRegister cr = new CashRegister();
		DispenserType cd = new DispenserType();

		boolean condition = true;

		do {
			System.out.println("Welcome to Vending Machine");

			System.out.println("Here are the list of items you can select from");
			System.out.println("1.Chips");
			System.out.println("2.Candies");
			System.out.println("3.Gums");
			System.out.println("4.Cookies");
			System.out.println("Please Enter your choice");

			Scanner sc = new Scanner(System.in);
			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Number of chips available: " + cd.show());

				System.out.println("Cost of chips is: " + cd.getCostofItems());

				int chips = 50;
				if (chips > 0) {
					chips = chips - 1;
					System.out.println("You chose potato chips.");
					System.out.println("That will be 10 Rs");
					System.out.println("How many Chips you want");
					chips = sc.nextInt();
					System.out.println("Pay The amount :"+(chips*10));
					int rupees = sc.nextInt();
					 {

					if (rupees < 10*chips) {
						System.out.println("You have not entered enough money. Have a great day.");
					} else if (rupees == 10*chips) {
						System.out.println("Here is your snack. Have a great day");
					} else if (rupees >= 10 * chips) {
						double change = rupees - 10 * chips;
						System.out.println("The items in the Dispenser : " + chips);
						System.out.println("Your change is Rupees" + change + ". Have a great day.");
				}
//				System.out.println("Items left in Machine :"+(cd.getNumberOfItems()-chips));
				
					 }}
					else {
					System.out.println("This item is out of stock. Please select another item.");
				}
				break;

			case 2:
				System.out.println("Number of candies available: " + cd.show());

				System.out.println("Cost of candies is: " + cd.getCostofItems());

				int candies = 50;
				if (candies > 0) {
					candies = candies - 1;
					System.out.println("You chooose candies.");
					System.out.println("That will be 10 Rs");
					System.out.println("How many candies you want");
					chips = sc.nextInt();
					System.out.println("Pay The amount :"+(candies*10));
					int rupees = sc.nextInt();
					 {

					if (rupees < 10*candies) {
						System.out.println("You have not entered enough money. Have a great day.");
					} else if (rupees == 10*candies) {
						System.out.println("Here is your snack. Have a great day");
					} else if((rupees >= 10 * candies)) {
						double change = (rupees - 10*candies);
						System.out.println("The items in the Dispenser : "+candies);
						System.out.println("Your change is Rupees" + change + ". Have a great day.");
					}
				}	
//					 System.out.println("Items left in Machine :"+(cd.getNumberOfItems()-candies));

				}	else {
					System.out.println("This item is out of stock. Please select another item.");
				}
				break;

			case 3:
				System.out.println("Number of gums available: " + cd.show());

				System.out.println("Cost of gums is: " + cd.getCostofItems());

				int gums = 50;
				if (gums > 0) {
					gums = gums - 1;
					System.out.println("You choose gums.");
					System.out.println("That will be 10 Rs");
					System.out.println("How many gums you want");
					gums = sc.nextInt();
					System.out.println("Pay The amount :"+(gums*10));
					int rupees = sc.nextInt();
					 {

					if (rupees < 10*gums) {
						System.out.println("You have not entered enough money. Have a great day.");
					} else if (rupees == 10*gums) {
						System.out.println("Here is your snack. Have a great day");
					} else if(rupees >= 10 * gums) {
						double change = (rupees - 10*gums);
						System.out.println("The items in the Dispenser : "+gums);
						System.out.println("Your change is Rupees" + change + ". Have a great day.");
					}
				}	
//					 System.out.println("Items left in Machine :"+(cd.getNumberOfItems()-gums));

				}	else {
					System.out.println("This item is out of stock. Please select another item.");
				}
				break;

			case 4:
				System.out.println("Number of cookies available: " + cd.show());

				System.out.println("Cost of cookies is: " + cd.getCostofItems());

				int cookies = 50;
				if (cookies > 0) {
					cookies = cookies - 1;
					System.out.println("You choose cookies.");
					System.out.println("That will be 10 Rs");
					System.out.println("How many candies you want");
					chips = sc.nextInt();
					System.out.println("Pay The amount :"+(cookies*10));
					int rupees = sc.nextInt();
					 {

					if (rupees < 10*cookies) {
						System.out.println("You have not entered enough money. Have a great day.");
					} else if (rupees == 10*cookies) {
						System.out.println("Here is your snack. Have a great day");
					} else if(rupees >= 10 * cookies){
						double change = (rupees - 10*cookies);
						System.out.println("The items in the Dispenser : "+cookies);
						System.out.println("Your change is Rupees" + change + ". Have a great day.");
					}
				}
//					 System.out.println("Items left in Machine :"+(cd.getNumberOfItems()-cookies));

				}	else {
					System.out.println("This item is out of stock. Please select another item.");
				}

				break;

			default:
				System.out.println("Choice Invalid");
				break;

			}
			System.out.println("Do you want to continue your transaction, please type: yes/no");
			System.out.println("To continue press any key");
			System.out.println("To cancel transaction press No");
			String response = sc.next();

			if (response.equals("no")) {
				System.out.println("Thank you!");
				int setcash = 0;
				System.out.println("Cash Register has: " + cr.getCurrentBalance());
				condition = false;
			}

		} while (condition);
	}

}
