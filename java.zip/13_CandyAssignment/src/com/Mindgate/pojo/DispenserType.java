package com.Mindgate.pojo;

public class DispenserType {
	
	private static int numberOfItems;
	private int costofItems;
	int chips;
	int candies;
	int gum;
	int cookies;

	public DispenserType() {
		setCostofItems(10);
		setNumberOfItems(50);

	}

//	public DispenserType(int x, int y) {
//		setCostofItems(x);
//		setNumberOfItems(y);
//	}

	public int getNumberOfItems() {
		return numberOfItems--;
	}

	public void setNumberOfItems(int numberOfItems) {
		this.numberOfItems = numberOfItems;
	}

	public int getCostofItems() {
		return costofItems;
	}

	public void setCostofItems(int costofItems) {
		this.costofItems = costofItems;
	}
	public int show() {
		return getCostofItems();
	}
	public int cost() {
		return getCostofItems();
	}
	public void makeSale() {
		 setNumberOfItems(getNumberOfItems()-1);
	}

}
