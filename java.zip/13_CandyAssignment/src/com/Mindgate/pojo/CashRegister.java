package com.Mindgate.pojo;

public class CashRegister {
	private static int cash;

	public CashRegister() {
		// TODO Auto-generated constructor stub
		setcash(500);
	}
	public CashRegister(int x) {
		setcash(x);
	
	}
	public int getCurrentBalance() {
		return cash;
	}
	public void setcash(int cash) {
		CashRegister.cash = cash;
	}
	public void acceptAccount(int x) {
		setcash(getCurrentBalance()+x);
	}
}

