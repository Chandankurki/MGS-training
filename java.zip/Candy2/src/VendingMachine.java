import java.util.Scanner;

public class VendingMachine {

	public static void main(String[] args) {

		Scanner userinput = new Scanner(System.in);
		int chips = 100;
		int candies = 10;
		int gum = 10;
		int cookies = 10;

		System.out.println("Select the number for the item you would like");
		System.out.println("For Chips, Enter 1");
		System.out.println("For Candies, Enter 2");
		System.out.println("For gum , Enter 3");
		System.out.println("For Cookies, Enter 4");
		int itemSelection = userinput.nextInt();

		if (itemSelection == 1) {

			if (chips > 0) {
				chips = chips - 1;
				System.out.println("You chose potato chips.");
				System.out.println("That will be 10 Rs");
				System.out.println("How many Chips you want");
				chips = userinput.nextInt();
				System.out.println("Enter The amount");
				int rupees = userinput.nextInt();
				{

					if (rupees < 10) {
						System.out.println("You have not entered enough money. Have a great day.");
					} else if (rupees == 10) {
						System.out.println("Here is your snack. Have a great day");
					} else {
						double change = (rupees - 10 * chips);
						System.out.println("The items in the Dispenser : " + chips);
						System.out.println("Your change is Rupees" + change + ". Have a great day.");
					}
				}

			} else {
				System.out.println("This item is out of stock. Please select another item.");
			}

		}

		if (itemSelection == 2) {

			if (candies > 0) {
				candies = candies - 1;
				System.out.println("You chose a candies.");
				System.out.println("That will be 5 Rs");
				System.out.println("How many candies do you want?");
				candies = userinput.nextInt();
				System.out.println("Enter The amount");
				int rupees = userinput.nextInt();

				if (rupees < 5) {
					System.out.println("You have not entered enough money. Have a great day.");
				} else if (rupees == 5) {
					System.out.println("Here is your snack. Have a great day");
				} else {
					double change = (rupees - 5 * candies);
					System.out.println("The items in the Dispenser : " + candies);
					System.out.println("Your change is Rupees" + change + ". Have a great day.");
				}
			}

			else {
				System.out.println("This item is out of stock. Please select another item.");
			}
		}

		if (itemSelection == 3) {

			if (gum > 0) {
				gum = gum - 1;
				System.out.println("You choose a gum.");
				System.out.println("That will be 5 Rs");
				System.out.println("How many gums do you want?");
				gum = userinput.nextInt();
				System.out.println("Enter The amount");
				int rupees = userinput.nextInt();

				if (rupees < 5) {
					System.out.println("You have not entered enough money. Have a great day.");
				} else if (rupees == 5) {
					System.out.println("Here is your snack. Have a great day");
				} else if (rupees >= 5 * gum) {
					double change = rupees - 5 * gum;
					System.out.println("The items in the Dispenser : " + gum);
					System.out.println("Your change is Rupees" + change + ". Have a great day.");
				}
			}

			else {
				System.out.println("This item is out of stock. Please select another item.");
			}
		}
		if (itemSelection == 4) {

			if (cookies > 0) {
				cookies = cookies - 1;
				System.out.println("You chose a cookies.");
				System.out.println("That will be 25 Rs");
				System.out.println("How many cookies do you want?");
				gum = userinput.nextInt();
				System.out.println("Enter The amount");
				int rupees = userinput.nextInt();

				if (rupees < 25) {
					System.out.println("You have not entered enough money. Have a great day.");
				} else if (rupees == 25) {
					System.out.println("Here is your snack. Have a great day");
				} else {
					double change = (rupees - 25 * cookies);
					System.out.println("The items in the Dispenser : " + cookies);
					System.out.println("Your change is Rupees" + change + ". Have a great day.");
				}
			}

			else {
				System.out.println("This item is out of stock. Please select another item.");
			}
		}

	}
}