package com.Mindgate.pojo;

public class YourClass extends MyClass {
	public static void print() {
		System.out.println("Print () of YourClass");
	}
}
