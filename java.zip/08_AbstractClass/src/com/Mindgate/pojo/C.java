package com.Mindgate.pojo;

abstract class A {
	public void print() {
		System.out.println("Hi");
	}
}
class B extends A{
	public void print() {
		System.out.println("hello");
	}
}
class C{
	public static void main(String[] args) {
		A a;
		a = new B();
		a.print();
	}

}