package com.Mindgate.pojo;

public abstract class MyClass {
	public static void show() {
		System.out.println("show() of MyClass");
		
	}
}
