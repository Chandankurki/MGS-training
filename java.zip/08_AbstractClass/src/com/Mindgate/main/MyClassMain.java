package com.Mindgate.main;

import com.Mindgate.pojo.MyClass;
import com.Mindgate.pojo.YourClass;

public class MyClassMain {
	public static void main(String[] args) {
//		MyClass myclass = new MyClass();
//		YourClass yourClass = new YourClass();
		
		YourClass.print();
		YourClass.show();
//		MyClass obja = new YourClass();
//		obja.print();
	}
}
