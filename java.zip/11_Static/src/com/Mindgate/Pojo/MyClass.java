package com.Mindgate.Pojo;

public class MyClass {
	public static int number1 = 10;
	public int number2 = 20;

	public static void print() {
		System.out.println("print() called");
		number1=12;
//		number2=5;
	}

	public void display() {
		System.out.println("Static variable number1 : " + number1);
		System.out.println("Non Static variable number2 : " + number2);
		number1++;
		number2++;
		System.out.println();
		System.out.println("Static variable number1 : " + number1);
		System.out.println("Non Static variable number2 : " + number2);
	}
}
