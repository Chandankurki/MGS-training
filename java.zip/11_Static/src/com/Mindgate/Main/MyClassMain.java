package com.Mindgate.Main;

import com.Mindgate.Pojo.MyClass;

public class MyClassMain {
	public static void main(String[] args) {
//		MyClass myclass = new MyClass();
//		myclass.display(); // 10 10
//		System.out.println("*************************");
//		System.out.println("After Increment");
//		MyClass myclass2 = new MyClass();
//		myclass2.display(); // 11 10 12 11
//		System.out.println("*************************");
//		System.out.println("After Increment");
//		MyClass myclass3 = new MyClass();
//		myclass3.display(); // 12 10 13 11

		MyClass.print();
		System.out.println(MyClass.number1);
		MyClass object = new MyClass();
		System.out.println(object.number2);
	}
}