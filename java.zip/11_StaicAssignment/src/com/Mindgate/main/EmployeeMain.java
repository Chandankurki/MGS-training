package com.Mindgate.main;

import com.Mindgate.pojo.Employee;

public class EmployeeMain {
	
	public static void main(String[] args) {
		Employee employee = new Employee("Chandan", 10000);
		Employee employee2 = new Employee("abhi", 10000);
		Employee employee3 = new Employee("Suman", 10000);
		
		System.out.println(employee);
		System.out.println(employee2);
		System.out.println(employee3);
		
		
	}
}
