
public class Dispenser {
	 private int numberOfItems;   
	    private int cost;   
	 
	    public Dispenser()
	    {
	         numberOfItems = 50;
	         cost = 50;
	    }
	 
	    public Dispenser(int setNoOfItems, int setCost)
	    {
	         if (setNoOfItems <= 0)
	         {
	             throw new RuntimeException("Your number of items must be greater than zero.");
	         }
	         else
	         {
	             numberOfItems = setNoOfItems;
	         }
	 
	         if (setCost <= 0)
	         {
	             throw new RuntimeException("Your cost must be greater than zero.");
	         }
	         else
	         {
	              cost = setCost;
	         }
	    }
	 
	    public int getCount()
	    {
	         return numberOfItems;
	    }
	 
	        public int getNumberOfItems() {
			return numberOfItems;
		}

		public void setNumberOfItems(int numberOfItems) {
			this.numberOfItems = numberOfItems;
		}

		public int getCost() {
			return cost;
		}

		public void setCost(int cost) {
			this.cost = cost;
		}

		//cost of the item
	    public int getProductCost()
	    {
	         return cost;
	    }
	 
	        //Subtracts the number of items by one
	    public void makeSale()
	    {
	        numberOfItems--;
	    }
}
