
public class CandyMachine {
	public static void main(String[] args)
	   {   
	        
	     System.out.println("Thank you for your purchase.");  
	   }
	   //Sells the product
	   public void sellProduct(Dispenser product, CashRegister amount)
	   {
	       int amountIn = 0;
	       int price, amountRequired;
	       if(product.getCount() < 0)
	       {
	           throw new RuntimeException("This is out of stock");
	       }
	       else
	       {
	           price = product.getProductCost();
	           amountRequired = price - amountIn;
	        }
	       amount.acceptAmount(amountIn);
	       product.makeSale();
	   }
}
