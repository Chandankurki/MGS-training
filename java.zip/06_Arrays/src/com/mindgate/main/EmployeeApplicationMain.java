package com.mindgate.main;

import com.mindgate.app.WEmployeeApplication;
import com.mindgate.pojo.Employee;

public class EmployeeApplicationMain {
	public static void main(String[] args) {
		WEmployeeApplication employeeApplication = new WEmployeeApplication();
		int x = 10;
		employeeApplication.print(x);
		
		Employee emp = new Employee(101, "chandan", 1000);
		Employee emp1 = new Employee(101, "vivek", 1000);
		employeeApplication.addEmployee(emp);
		employeeApplication.addEmployee(emp1);
		System.out.println("******************************************************");

		employeeApplication.printAllEmployees();
		
	}
}


