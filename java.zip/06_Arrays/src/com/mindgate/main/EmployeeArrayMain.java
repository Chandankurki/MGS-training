package com.mindgate.main;

import com.mindgate.pojo.Employee;

public class EmployeeArrayMain {
	public static void main(String[] args) {
		
		
		int [] numbers =new int[5];
		Employee [] emp = new Employee[5];
		
		Employee emp1= new Employee(101, "Chandan", 1000);
		Employee emp2= new Employee(102, "aravind", 1000);
		Employee emp3= new Employee(103, "santhosh", 1000);
		Employee emp4= new Employee(104, "asiq", 1000);
		Employee emp5= new Employee(105, "hari", 1000);
		
		emp[0] = emp1;
		emp[1] = emp2;
		emp[2] = emp3;
		emp[3] = emp4;
		emp[4] = emp5;
		
		for (Employee e : emp) {
			System.out.println(e);
			System.out.println();
		}
		
 	}
}
