package com.mindgate.main;

public class ArrayMain {
	public static void main(String[] args) {
		System.out.println("Main start");
		
		int[] numbers =new int[5];
		numbers[0] =101;
		numbers[1] =102;
		numbers[2] =103;
		numbers[3] =104;
		numbers[4] =105;
		for(int i : numbers) {
			System.out.println("inside array");
			System.out.println(i);
		}
		System.out.println("Main end");
	}
}
