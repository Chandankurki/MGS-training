package com.mindgate.pojo;

public class Employee {
	private int empoyeeID;
	private String name;
	private double salary;
	
	public Employee() {
		
	}

	public Employee(int empoyeeID, String name, double salary) {
		super();
		this.empoyeeID = empoyeeID;
		this.name = name;
		this.salary = salary;
	}

	public int getEmpoyeeID() {
		return empoyeeID;
	}

	public void setEmpoyeeID(int empoyeeID) {
		this.empoyeeID = empoyeeID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [empoyeeID=" + empoyeeID + ", name=" + name + ", salary=" + salary + "]";
	}
	
	 
}
