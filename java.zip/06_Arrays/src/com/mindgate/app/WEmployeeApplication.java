package com.mindgate.app;

import java.util.Iterator;

import com.mindgate.pojo.Employee;

public class WEmployeeApplication {
	private Employee[] employees = new Employee[5];
	private int index =0;
	private Employee [] emp = new Employee[5];
	
	public void print(int x) {
		System.out.println("Inside print");
		System.out.println(x);
		
	}
	public void addEmployee(Employee emp) {
		System.out.println("Inside addEmployee");
		System.out.println(emp);
		employees[index] = emp;
		index = index+1;
		
	}
	public void printAllEmployees() {
		for (Employee emp : employees) {
			System.out.println(emp);
		}
	}
}
