package com.Mindgate.main;

import java.util.Scanner;

import com.Mindgate.pojo.Accounts;

public class AccountMainV3 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Acount Number");
		int accountNumber = scanner.nextInt();
		System.out.println("Enter Name");
		String name = scanner.next();
		System.out.println("Enter Balance");
		double balance = scanner.nextDouble();
		Accounts accounts = new Accounts(accountNumber, name, balance);
		System.out.println("Withdraw  :: 300");
		boolean withdrawResult = accounts.withdraw(300);
		if (withdrawResult) {
			System.out.println("Withdraw Successful");
			System.out.println(accounts.getBalance());
		}
		else {
			System.out.println("Withdraw Faied");
			System.out.println(accounts.getBalance());
		}
		System.out.println(accounts);
		
	}
}
