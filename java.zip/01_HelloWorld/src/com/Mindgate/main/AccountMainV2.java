package com.Mindgate.main;

import com.Mindgate.pojo.Accounts;

public class AccountMainV2 {
	public static void main(String[] args) {
		System.out.println("Main start");
//		overloaded constructor
		Accounts accounts =new Accounts(100, "Chandan" , 1000);
//		System.out.println("Account Number::" +accounts.getAccountNumber());
//		System.out.println("Name :: "+accounts.getName());
//		System.out.println("Balance :: " +accounts.getBalance());
		System.out.println(accounts);
			
		System.out.println("Main end");
	}
}
