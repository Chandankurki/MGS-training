package com.Mindgate.main;

import com.Mindgate.pojo.Accounts;

public class AccountsMain {
	public static void main(String[] args) {
		System.out.println("Hello World");
		
//		wanted to set the values to Account class
//		create the object of Account class
		Accounts accounts = new Accounts();
		System.out.println("Account object is created");
		System.out.println("setting the value from object");
		accounts.setAccountNumber(101);
		accounts.setName("chandan");
		accounts.setBalance(100);
		
		System.out.println("getting th value from object");
		System.out.println(accounts.getAccountNumber());
		System.out.println(accounts.getName());
		System.out.println(accounts.getBalance());
	}

}
