package com.Mindgate.main;

import java.util.Scanner;

import com.Mindgate.pojo.Accounts;

public class AccountMainV4 {
	public static void main(String[] args) {
		System.out.println("Welcome to to Mindgate Bank");
		System.out.println("Please enter details to open new account");
		Scanner scanner = new Scanner(System.in);
		String continueChoice;
		System.out.println("Enter Account Number");
		int accountNumber = scanner.nextInt();
		System.out.println("Enter Name");
		String name = scanner.next();
		System.out.println("Enter Balance");
		double balance = scanner.nextDouble();
		System.out.println("Your Account is opened successfully.");

		Accounts accounts = new Accounts(accountNumber, name, balance);
		System.out.println("Account Details  ");
		System.out.println(accounts);
		do {
			System.out.println("Menu");
			System.out.println("Press 1. Withdraw");
			System.out.println("Press 2. Deposit");
			System.out.println("Press 3. Balance");
			System.out.println("Enter your choice");

			int choice = scanner.nextInt();

			switch (choice) {
			case 1: {
				System.out.println("Enter the amount to be withdrawn");
				double amount = scanner.nextDouble();
				boolean withdrawResults = accounts.withdraw(amount);
				if (withdrawResults) {
					System.out.println("Withdraw succesful");
					System.out.println("Withdrawn Amount " + amount);
//				System.out.println("Account Balance : " + accounts.getBalance());
				} else {
					System.out.println("Withdraw failed");
					System.out.println("Account Balance :" + accounts.getBalance());
				}
			}

				break;
			case 2: {
				System.out.println("Enter the amount to be Deposited");
				double amount = scanner.nextDouble();
				boolean Deposit = accounts.deposit(amount);
				if (Deposit) {
					System.out.println("Deposit succesful");
					System.out.println("Deposited Amount " + amount);
//				System.out.println("Account Balance : " + accounts.getBalance());
				} else {
					System.out.println("Deposit failed");
					System.out.println("Account Balance :" + accounts.getBalance());
				}
			}
				break;
			case 3:
				System.out.println("Account balance :" + accounts.getBalance());
			}
			System.out.println("Do you want to continue ?");
			System.out.println("Press Y to continue else Press N");
			continueChoice = scanner.next();
		} while (continueChoice.equals("y"));
	}
}