	 package com.Mindgate.main;

import java.util.Scanner;

import com.Mindgate.pojo.Accounts;

public class AccountMainV5 {
	public static void main(String[] args) {
		System.out.println("Welcome to Mindgate Bank");
		System.out.println("Please enter details to open new account");
		Scanner sc = new Scanner(System.in);
		String continueChoice;
		System.out.println("Enter Your Account Number : ");
		int accountNumber = sc.nextInt();
		System.out.println("Enter Your Name : ");
		String name = sc.next();
		System.out.println("Enter Your Balance : ");
		double balance= sc.nextDouble();
		
		System.out.println("Your accout is opened successfully.");
		Accounts accounts = new Accounts(accountNumber, name, balance );
		System.out.println("Account Details ");
		System.out.println(accounts);
		do {
			System.out.println("Menu :- ");
			System.out.println("Press 1. Withdraw");
			System.out.println("Press 2. Deposit");
			System.out.println("Press 3. Balance");
			System.out.println("Enter your choice");
			
			int choice = sc.nextInt();
			
			switch (choice) {
			case 1:{
				System.out.println("Enter the amount to be Withdrawn");
				double amount = sc.nextDouble();
				boolean withdraw = accounts.withdraw(amount);
				if(withdraw) {
					System.out.println("Withdrawn successful");
				}else {
					System.out.println("Withdrawn Failed");
				}}
			break;
			case 2 :{
				System.out.println("Enter the amount to be Deposit");
				double amount = sc.nextDouble();
				boolean deposit = accounts.deposit(amount);
				if(deposit) {
					System.out.println("Deposit successful");
				}else {
				System.out.println("Deposit Failed");
			}
				
			}
			break;
			case 3:{
				System.out.println("Accounts balance : "+ accounts.getBalance());
			}
			}
			System.out.println("Do you want to continue ?");
			System.out.println("Press Y to continue else Press N");
			continueChoice = sc.next();
			

		}while(continueChoice.equals("y"));
		
		
	}
}
