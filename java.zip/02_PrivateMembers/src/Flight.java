
public class Flight {
	public static void main(String[] args) {
		
	}
}
