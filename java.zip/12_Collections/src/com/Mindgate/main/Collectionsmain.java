package com.Mindgate.main;

import java.util.ArrayList;
import java.util.List;

import com.Mindgate.pojo.Employee;

public class Collectionsmain {
//	collections vs array
	public static void main(String[] args) {

		List<String> employeeNames = new ArrayList<String>();
//	employeeNames.add("Chandan");
//	employeeNames.add("Harish");
//	employeeNames.add("Suman");
//	employeeNames.add("Santosh");

		String name1 = new String("Chandan");
		String name2 = new String("suman");
		String name3 = new String("santhosh");
		employeeNames.add(name3);
		employeeNames.add(name2);
		employeeNames.add(name1);
		employeeNames.add(new String("Chandan1")); // we can create in this form also
//		System.out.println(employeeNames);
		for (String name : employeeNames) {
			System.out.println(name);
		}
		System.out.println("--------------------------------");

		ArrayList<Employee> employeeList = new ArrayList<Employee>();
		{
			Employee employee1 = new Employee(101, "Chandan", 10000);
			Employee employee2 = new Employee(102, "Suman", 10000);
			employeeList.add(employee1);
			employeeList.add(employee2);
//			System.out.println(employeeList);
			
		for(Employee e: employeeList) {
			System.out.println(e);
		}

	}}
}