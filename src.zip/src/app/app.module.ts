import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './component/login/login.component';
import { RegisterComponent } from './component/register/register.component';

import { HttpClientModule } from '@angular/common/http';
import { AdminComponent } from './component/admin/admin.component';
import { CustomerComponent } from './component/customer/customer.component';
import { FormsModule } from '@angular/forms';
import { AllCustomersComponent } from './component/admin/All-customers/all-customers/all-customers.component';
import { CustomerRequestsComponent } from './component/admin/customer-Requests/customer-requests/customer-requests.component';
import { AccountDetailsComponent } from './component/customer/account-details/account-details.component';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    AdminComponent,
    CustomerComponent,
    AllCustomersComponent,
    CustomerRequestsComponent,
    AccountDetailsComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
