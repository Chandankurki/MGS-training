import { AccountDetails } from "./account-details";

export class transactionDetails {
    transaction_id: number = 0;
    account_id_from: number = 0;
    account_id_to: number = 0;
    transaction_amount: number = 0;
    transaction_date: Date = new Date();
    transaction_time: Date = new Date();
    transaction_type: string = '';

    accountdetails: AccountDetails = new AccountDetails();
}