import { AccountDetails } from "./account-details";

export class BankSlip {
    bankSlipId: number = 0;
    accountIdFrom: number = 0;
    accountIdTo: number = 0;
    chequeNo: number = 0;
    payerAccountId: number = 0;
    amount: number = 0;

    accountdetails: AccountDetails = new AccountDetails();


}