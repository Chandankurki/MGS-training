import { CustomerDetails } from "./customer-details";

export class AccountDetails {
    accountId: string= '';
    accountStatus: string = '';
    currentBalance: number = 0;
    minimumBalance: number = 0;
    rateOfInterest: number = 0;
    overdraft: number = 0;
    typeOfAccount:string='';
    openingDate: Date = new Date();
    customerDetails: CustomerDetails = new CustomerDetails();


}