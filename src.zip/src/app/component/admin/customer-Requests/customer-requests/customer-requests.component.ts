import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RegisterService } from '../../../../service/register/register.service';
import { CustomerDetails } from '../../../../pojo/customer-details';
import { CustomerService } from '../../../../service/customer/customer.service';
import { AccountDetails } from '../../../../pojo/account-details';

@Component({
  selector: 'app-customer-requests',
  templateUrl: './customer-requests.component.html',
  styleUrls: ['./customer-requests.component.css']
})
export class CustomerRequestsComponent implements OnInit {

  customerdetails: CustomerDetails[] = [];
  accountDetails: AccountDetails[] = [];
  accountObj: AccountDetails = new AccountDetails();
  customerObj: CustomerDetails = new CustomerDetails();
  result: boolean = false;
  submitted: boolean = false;
  customerId: string = '';
  customerResult: boolean = false;
  constructor(private router: Router, private RegisterService: RegisterService, private customerService: CustomerService) { }

  ngOnInit(): void {
    this.reloadData();
  }

  reloadData() {
    this.customerService.getallcustomer().subscribe(data => {
      this.accountDetails = data;
      this.customerObj = this.accountObj.customerDetails;
      console.log("All Customers :: " + this.customerdetails);
      console.log(this.customerdetails);
    });
  }

  decline(accept: any) {
    this.accountObj = accept
    this.accountObj.accountStatus = "decline";
    console.log("customer obj :: ");
    console.log(this.customerObj);
    console.log("decline method() :: " + this.accountObj.accountStatus);
    this.RegisterService.decline(this.accountObj).subscribe(data => {
      console.log("button :: " + this.accountObj.accountStatus);
      this.result = data;
      if (this.result == true)
        this.reloadData();
      console.log("button :: " + this.accountObj.accountStatus);
      console.log("declined customer");
    })
    this.accountObj.customerDetails.customerStatus = "decline";
    this.RegisterService.customerDecline(this.accountObj.customerDetails).subscribe(data => {
      this.customerResult = data;
      console.log("Customer status :: " + data);
    });
  }

  approve(accept: any) {
    this.accountObj = accept
    this.accountObj.accountStatus = "approved";
    console.log("aprroved method() :: " + this.accountObj.accountStatus);
    console.log("aprroved method() customer details:: ");
    console.log(this.accountObj.customerDetails);
    this.RegisterService.approve(this.accountObj).subscribe(data => {
      this.result = data;
      this.submitted = data;
    });
    this.accountObj.customerDetails.customerStatus = "approved";
    this.RegisterService.customerApproved(this.accountObj.customerDetails).subscribe(data => {
      this.customerResult = data;
      console.log("Customer status :: " + data);
    });
  }
}