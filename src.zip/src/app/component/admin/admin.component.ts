import { Component, OnInit } from '@angular/core';
import { CustomerDetails } from '../../pojo/customer-details';
import { CustomerService } from '../../service/customer/customer.service';
import { AccountDetails } from '../../pojo/account-details';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  getallEmployees : AccountDetails[] = []; 
  customerId:string='';
  constructor(private CustomerService:CustomerService) { }

  ngOnInit(): void {
  }
  loginBtn(){

  }
  reloadData(){
    this.CustomerService.getallcustomer().subscribe(data=>{
      this.getallEmployees=data;
      console.log(data);
    });
  }
}


