import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginDetails } from '../../../../pojo/login-details';
import { LoginService } from '../../../../service/login/login.service';
import { CustomerService } from '../../../../service/customer/customer.service';
import { CustomerDetails } from '../../../../pojo/customer-details';


@Component({
  selector: 'app-all-customers',
  templateUrl: './all-customers.component.html',
  styleUrls: ['./all-customers.component.css']
})
export class AllCustomersComponent implements OnInit {

  getallcustomer :CustomerDetails[]=[];
  result:boolean=false;
  constructor(private router: Router,private CustomerService:CustomerService) { }

  ngOnInit(): void {
    this.reloadData();
  }

  reloadData(){
    // this.CustomerService.getallcustomer().subscribe(data=>{
    //   // this.getallcustomer=data;
    //   console.log(data);
    // });
  }

  deletebtn(customerId: string) {
    // this.CustomerService.deletecustomer(customerId).subscribe((data: boolean)=>{
    //   this.result=data;
    //   if(this.result==true){
    //     this.reloadData();
    //   }
    // })
    
  }

  customerdetails(customerId : string) {
    console.log("userID "+customerId);
    this.router.navigate(['getallcustomer',customerId]);
  }

  block() {

  }

}
