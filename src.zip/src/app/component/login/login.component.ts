import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginDetails } from 'src/app/pojo/login-details';
import { LoginService } from '../../service/login/login.service';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  login: LoginDetails = new LoginDetails();
  error:string="";

  constructor(private loginService: LoginService , private router: Router) { }

  ngOnInit(): void {
  }

  loginBtn(userId : string) {
    console.log(this.login);
    this.loginService.login(this.login).subscribe(data => {
      this.login = data;
      if (data.role == "customer") {
        this.router.navigate(['customer',userId]);
      }
      else if (data.role == "admin") {
        this.router.navigate(['admin']);
      }
    }, error  =>{
      this.error="Invalid UserName and Password !! Try Again"
      console.log("Error CNJB",error);
    }    
    );
  }
  

}
