import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../../service/customer/customer.service';
import { CustomerDetails } from '../../pojo/customer-details';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountDetails } from '../../pojo/account-details';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})

export class CustomerComponent implements OnInit {
  userId: string = '';
  accountId:string='';
  accountDetails: AccountDetails = new AccountDetails();
  customerdetails: CustomerDetails = new CustomerDetails();
  allAccountDetails: AccountDetails[] = [];
  constructor(private CustomerService: CustomerService, private route: ActivatedRoute, private router:Router) { }

  ngOnInit(): void {
    this.userId = this.route.snapshot.params['userId'];
    console.log(this.userId);
    console.log(this.accountDetails);
    this.CustomerService.getcustomerdetailsbyuserid(this.userId).subscribe(data => {
      console.log(this.userId);
      this.customerdetails = data;
      console.log(this.customerdetails);
      this.CustomerService.getcustomerdetailsbycustomerid(this.customerdetails.customerId).subscribe(data => {
        this.allAccountDetails = data;
        console.log(this.allAccountDetails);

      });
    });
  }


  details(accountId:string){
    this.router.navigate(['accountdetails']);
  }
}