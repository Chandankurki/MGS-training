import { Component, OnInit } from '@angular/core';
import { CustomerDetails } from 'src/app/pojo/customer-details';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  register : CustomerDetails = new CustomerDetails();
  
  constructor() { }

  ngOnInit(): void {
  }

  registerBtn(){
    console.log(this.register);
  }

}
