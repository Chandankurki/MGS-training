import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { LoginDetails } from '../../pojo/login-details';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  private baseURL: string = "http://192.168.1.229:8080/netbankingapi/";

  constructor(private http: HttpClient) { }

  login(login: LoginDetails): Observable<LoginDetails> {
    return this.http.post<LoginDetails>(this.baseURL + "logindetails",login);
  }

  getall():Observable<LoginDetails[]>{
    return this.http.get<LoginDetails[]>(this.baseURL+"getalldetails")
  }

}
