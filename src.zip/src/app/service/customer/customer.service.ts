import { Injectable } from '@angular/core';
import { CustomerDetails } from '../../pojo/customer-details';
import { Observable } from 'rxjs';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AccountDetails } from '../../pojo/account-details';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  private baseURL: string = "http://192.168.1.229:8080/netbankingapi/";

  constructor(private HttpClientModule: HttpClient) { }

  getcustomerdetails(): Observable<AccountDetails[]> {
    return this.HttpClientModule.get<AccountDetails[]>(this.baseURL + "accountdetails/pendingaccounts");
  }

  getcustomerdetailsbyuserid(userId: string): Observable<CustomerDetails> {
    console.log("Service User ID :: " + userId);
    return this.HttpClientModule.get<CustomerDetails>(this.baseURL + "customerdetailsbyuserid/" + userId);
  }

  getcustomerdetailsbycustomerid(customerId: string): Observable<AccountDetails[]> {
    console.log("Service customer ID :: " + customerId);
    return this.HttpClientModule.get<AccountDetails[]>(this.baseURL + "accountdetails/" + customerId);
  }


  getallcustomer(): Observable<AccountDetails[]> {
    return this.HttpClientModule.get<AccountDetails[]>(this.baseURL + "accountdetails/pendingaccounts");
  }
}
