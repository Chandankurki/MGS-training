import { NgModule, Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './component/admin/admin.component';
import { CustomerComponent } from './component/customer/customer.component';
import { LoginComponent } from './component/login/login.component';
import { RegisterComponent } from './component/register/register.component';
import { CustomerRequestsComponent } from './component/admin/customer-Requests/customer-requests/customer-requests.component';
import { AllCustomersComponent } from './component/admin/All-customers/all-customers/all-customers.component';
import { AccountDetailsComponent } from './component/customer/account-details/account-details.component';

const routes: Routes = [
  {path:"register",component:RegisterComponent},
  {path:"",component:LoginComponent},
  {path:"login",component:LoginComponent},
  {path:"admin",component:AdminComponent},
  {path:"customer/:userId",component:CustomerComponent},
  {path:"customerrequest", component:CustomerRequestsComponent},
  {path:"allcustomers", component:AllCustomersComponent},
  {path:"accountdetails", component:AccountDetailsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
