package com.mindgate.main.services;

import com.mindgate.main.pojo.Employee;

public interface EmployeeServiceInterface {
	boolean addEmployee(Employee employee);
	boolean updateEmployee(Employee employee);
	boolean deleteEmployee(int employeeId);
	Employee getEmployeebyEmployeeId();
	List<Employee> 
}
